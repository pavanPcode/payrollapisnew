const express = require('express');
const router = express.Router();

// Export the router to be used in the app
module.exports = router;
